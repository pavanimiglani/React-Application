import Todo from './Todo';
import './App.css';

function App(){
    return(
    <div className = "App">
      <Todo/>
      </div>
    );
}

export default App; 




        
       

