
import React from 'react';
import Greeter from '/Greeter.js'; //Import the Greater Component 

function App(){
  return (
    <div>
      <h1>Welcome to my React App</h1>
      <Greeter /> {/*Use the Greater component*/}
    </div>
  );
}

export default App;

